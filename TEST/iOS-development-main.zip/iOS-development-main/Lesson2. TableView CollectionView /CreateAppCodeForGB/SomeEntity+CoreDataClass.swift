//
//  SomeEntity+CoreDataClass.swift
//  CreateAppCodeForGB
//
//  Created by Максим Бобков on 25.01.2024.
//
//

import Foundation
import CoreData

@objc(SomeEntity)
public class SomeEntity: NSManagedObject {

}
