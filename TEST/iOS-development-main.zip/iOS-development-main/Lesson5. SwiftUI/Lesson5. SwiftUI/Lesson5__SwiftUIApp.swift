//
//  Lesson5__SwiftUIApp.swift
//  Lesson5. SwiftUI
//
//  Created by Максим Бобков on 27.01.2024.
//

import SwiftUI

@main
struct Lesson5__SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
