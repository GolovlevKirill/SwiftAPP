//
//  ViewController.swift
//  Homework1. Storyboard
//
//  Created by Максим Бобков on 04.01.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

