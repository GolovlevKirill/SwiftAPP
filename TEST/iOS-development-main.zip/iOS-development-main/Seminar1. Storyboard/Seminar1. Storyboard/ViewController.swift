//
//  ViewController.swift
//  MyProject
//
//  Created by Максим Бобков on 04.01.2024.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

