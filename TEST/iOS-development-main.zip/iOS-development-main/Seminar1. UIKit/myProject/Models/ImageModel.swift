//
//  ImageModel.swift
//  myProject
//
//  Created by Максим Бобков on 15.01.2024.
//

struct ImageModel: Decodable {
    let url: String
}
