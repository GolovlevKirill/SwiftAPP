//
//  ViewController.swift
//  Architecture
//
//  Created by Максим Бобков on 29.01.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

