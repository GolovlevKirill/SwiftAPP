//
//  FriendsDate+CoreDataClass.swift
//  Homework6
//
//  Created by Максим Бобков on 06.02.2024.
//
//

import Foundation
import CoreData

@objc(FriendsDate)
public class FriendsDate: NSManagedObject {

}
