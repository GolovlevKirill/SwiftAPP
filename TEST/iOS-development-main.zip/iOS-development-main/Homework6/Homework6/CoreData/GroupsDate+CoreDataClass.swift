//
//  GroupsDate+CoreDataClass.swift
//  Homework6
//
//  Created by Максим Бобков on 06.02.2024.
//
//

import Foundation
import CoreData

@objc(GroupsDate)
public class GroupsDate: NSManagedObject {

}
