//
//  Homework5__SwiftUIApp.swift
//  Homework5. SwiftUI
//
//  Created by Максим Бобков on 27.01.2024.
//

import SwiftUI

@main
struct Homework5__SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
