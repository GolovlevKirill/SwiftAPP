//
//  ViewController.swift
//  GbSwiftAppHW01
//
//  Created by Лариса on 07/01/2024.
//  Copyright © 2024 Kirill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

